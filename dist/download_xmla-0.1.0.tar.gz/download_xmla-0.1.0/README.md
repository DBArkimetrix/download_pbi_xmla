# Savaria Download

This package allows you to fetch and save Power BI tables via the XMLA endpoint.

## Installation

```bash
poetry add my_package

### Usage
fetch_tables --server SERVER_URL --db_name DATABASE_NAME --username USERNAME --password PASSWORD --tables Table1 Table2

